# QuickChat Project

This project demonstrates:
- Loops
- String handling
- Message validation
- JUnit testing
- GitHub Actions CI

## Features
1. Send Messages
2. Recently Sent Messages (Coming Soon)
3. Quit

## Test Data Updated
Recipient numbers now start with 0 instead of +27 to satisfy the 10-character requirement.

Example:
0718693002
0857597588
