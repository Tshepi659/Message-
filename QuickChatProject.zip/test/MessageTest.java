import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {

        Message msg = new Message();
        msg.setMessage("Hello");

        assertEquals(
                "Message ready to send.",
                msg.validateMessage()
        );
    }

    @Test
    public void testMessageLengthFailure() {

        Message msg = new Message();

        msg.setMessage("A".repeat(260));

        assertTrue(
                msg.validateMessage().contains("Message exceeds 250 characters")
        );
    }

    @Test
    public void testRecipientSuccess() {

        Message msg = new Message();

        msg.setRecipient("0718693002");

        assertEquals(
                "Cell phone number successfully captured.",
                msg.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientFailure() {

        Message msg = new Message();

        msg.setRecipient("+27718693002");

        assertTrue(
                msg.checkRecipientCell().contains("incorrectly formatted")
        );
    }

    @Test
    public void testCreateMessageHash() {

        Message msg = new Message();

        msg.setMessageID("0012345678");
        msg.setNumMessagesSent(0);

        msg.setMessage(
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "00:0:HITONIGHT",
                msg.createMessageHash()
        );
    }

    @Test
    public void testSentMessage() {

        Message msg = new Message();

        assertEquals(
                "Message successfully sent.",
                msg.sentMessage(1)
        );

        assertEquals(
                "Press 0 to delete the message.",
                msg.sentMessage(2)
        );

        assertEquals(
                "Message successfully stored.",
                msg.sentMessage(3)
        );
    }
}
