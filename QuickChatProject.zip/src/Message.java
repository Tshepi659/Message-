import java.util.Random;

public class Message {

    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String message;
    private String messageHash;

    public String generateMessageID() {

        Random random = new Random();

        long number = 1000000000L +
                (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {

        if (recipient.startsWith("0") && recipient.length() <= 10) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String validateMessage() {

        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {

            int excess = message.length() - 250;

            return "Message exceeds 250 characters by "
                    + excess +
                    ", please reduce the size.";
        }
    }

    public String createMessageHash() {

        String[] words = message.split(" ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        return messageID.substring(0, 2)
                + ":" +
                numMessagesSent
                + ":" +
                (firstWord + lastWord).toUpperCase();
    }

    public String sentMessage(int option) {

        switch (option) {

            case 1:
                return "Message successfully sent.";

            case 2:
                return "Press 0 to delete the message.";

            case 3:
                return "Message successfully stored.";

            default:
                return "Invalid option.";
        }
    }

    public String printMessages() {

        return "Message ID: " + messageID +
                "\nMessage Hash: " + messageHash +
                "\nRecipient: " + recipient +
                "\nMessage: " + message;
    }

    public int returnTotalMessages() {
        return numMessagesSent;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public void setNumMessagesSent(int numMessagesSent) {
        this.numMessagesSent = numMessagesSent;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }
}
