import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        boolean loggedIn = true;

        if (!loggedIn) {
            System.out.println("Please login first.");
            return;
        }

        System.out.println("Welcome to QuickChat.");

        System.out.print("How many messages would you like to send? ");
        int totalMessages = input.nextInt();
        input.nextLine();

        int sentCount = 0;
        boolean running = true;

        while (running) {

            System.out.println("\n1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");

            int choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:

                    while (sentCount < totalMessages) {

                        Message msg = new Message();

                        msg.setNumMessagesSent(sentCount);

                        System.out.print("Enter recipient number: ");
                        msg.setRecipient(input.nextLine());

                        System.out.println(msg.checkRecipientCell());

                        System.out.print("Enter message: ");
                        msg.setMessage(input.nextLine());

                        System.out.println(msg.validateMessage());

                        msg.setMessageID(msg.generateMessageID());
                        msg.setMessageHash(msg.createMessageHash());

                        System.out.println("\nChoose option:");
                        System.out.println("1. Send Message");
                        System.out.println("2. Disregard Message");
                        System.out.println("3. Store Message");

                        int option = input.nextInt();
                        input.nextLine();

                        System.out.println(msg.sentMessage(option));

                        if (option == 1 || option == 3) {

                            System.out.println("\n----- MESSAGE DETAILS -----");
                            System.out.println(msg.printMessages());

                            sentCount++;
                        }

                        if (sentCount >= totalMessages) {
                            break;
                        }
                    }

                    System.out.println("Total messages sent: " + sentCount);
                    break;

                case 2:
                    System.out.println("Coming Soon.");
                    break;

                case 3:
                    running = false;
                    System.out.println("Application closed.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }

        input.close();
    }
}
